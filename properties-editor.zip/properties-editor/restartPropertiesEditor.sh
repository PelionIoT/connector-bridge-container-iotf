#!/bin/sh

cd ${HOME}/properties-editor/scripts
./killPropertiesEditor.sh
./runPropertiesEditor.sh &
